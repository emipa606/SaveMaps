﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using RimWorld;
using Verse;

namespace LocationGeneration
{
    public class Dialog_SaveEverything : Dialog_Rename
    {
        private bool includePawns;
        public Dialog_SaveEverything(string name, bool includePawns = true)
        {
            this.name = name;
            this.includePawns = includePawns;
        }

        protected override void SetName(string name)
        {
            this.name = GenText.SanitizeFilename(name);
            Map map = Find.CurrentMap;
            string path = BlueprintUtility.GetConfigPath(this.name);
            BlueprintUtility.SaveEverything(path, map, includePawns);
        }

        private string name;
    }
}

