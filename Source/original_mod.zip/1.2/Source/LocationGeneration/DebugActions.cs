﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using UnityEngine;
using Verse;

namespace LocationGeneration
{
    [StaticConstructorOnStartup]
    public static class Actions
    {
        [DebugAction("Save Maps", "Save everything")]
        public static void SaveEverything()
        {
            string name = "";
            var dialog = new Dialog_SaveEverything(name);
            Find.WindowStack.Add(dialog);
        }

        [DebugAction("Save Maps", "Save everything w/o colonists")]
        public static void SaveEverythingWithoutColonists()
        {
            string name = "";
            var dialog = new Dialog_SaveEverything(name, false);
            Find.WindowStack.Add(dialog);
        }

        [DebugAction("Save Maps", "Save in home area with colonists")]
        public static void CreateBlueprint()
        {
            string name = "";
            var dialog = new Dialog_NameBlueprint(name, true);
            Find.WindowStack.Add(dialog);
        }

        [DebugAction("Save Maps", "Save in home area w/o colonists")]
        public static void CreateBlueprintWithoutColonists()
        {
            string name = "";
            var dialog = new Dialog_NameBlueprint(name, false);
            Find.WindowStack.Add(dialog);
        }

        [DebugAction("Save Maps", "Load blueprint")]
        public static void LoadBlueprint()
        {
            var curModName = LoadedModManager.RunningMods.Where(x => x.assemblies.loadedAssemblies.Contains(Assembly.GetExecutingAssembly())).FirstOrDefault().Name;
            string path = BlueprintUtility.GetConfigPath();
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            if (!directoryInfo.Exists)
            {
                directoryInfo.Create();
            }
            
            List<DebugMenuOption> list = new List<DebugMenuOption>();
            using (IEnumerator<FileInfo> enumerator = directoryInfo.GetFiles().AsEnumerable().GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    string name = enumerator.Current.Name;
                    list.Add(new DebugMenuOption(name, 0, delegate ()
                    {
                        path = path + "/" + name;
                        Map map = Find.CurrentMap;
                        SettlementGeneration.DoSettlementGeneration(map, path, null, Faction.OfPlayer, false);
                    }));
                }
            }
            if (list.Any())
            {
                Find.WindowStack.Add(new Dialog_DebugOptionListLister(list));
            }
        }

        [DebugAction("Save Maps", "Load blueprint (override)")]
        public static void LoadBlueprintDestroyEverything()
        {
            var curModName = LoadedModManager.RunningMods.Where(x => x.assemblies.loadedAssemblies.Contains(Assembly.GetExecutingAssembly())).FirstOrDefault().Name;
            string path = BlueprintUtility.GetConfigPath();
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            if (!directoryInfo.Exists)
            {
                directoryInfo.Create();
            }

            List<DebugMenuOption> list = new List<DebugMenuOption>();
            using (IEnumerator<FileInfo> enumerator = directoryInfo.GetFiles().AsEnumerable().GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    string name = enumerator.Current.Name;
                    list.Add(new DebugMenuOption(name, 0, delegate ()
                    {
                        path = path + "/" + name;
                        Map map = Find.CurrentMap;
                        SettlementGeneration.DoSettlementGeneration(map, path, null, Faction.OfPlayer, false, true);
                    }));
                }
            }
            if (list.Any())
            {
                Find.WindowStack.Add(new Dialog_DebugOptionListLister(list));
            }
        }

        [DebugAction("Save Maps", "Load blueprint (override, except colonists)")]
        public static void LoadBlueprintDestroyEverythingExceptColonists()
        {
            var curModName = LoadedModManager.RunningMods.Where(x => x.assemblies.loadedAssemblies.Contains(Assembly.GetExecutingAssembly())).FirstOrDefault().Name;
            string path = BlueprintUtility.GetConfigPath();
            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            if (!directoryInfo.Exists)
            {
                directoryInfo.Create();
            }

            List<DebugMenuOption> list = new List<DebugMenuOption>();
            using (IEnumerator<FileInfo> enumerator = directoryInfo.GetFiles().AsEnumerable().GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    string name = enumerator.Current.Name;
                    list.Add(new DebugMenuOption(name, 0, delegate ()
                    {
                        path = path + "/" + name;
                        Map map = Find.CurrentMap;
                        SettlementGeneration.DoSettlementGeneration(map, path, null, Faction.OfPlayer, false, true, true);
                    }));
                }
            }
            if (list.Any())
            {
                Find.WindowStack.Add(new Dialog_DebugOptionListLister(list));
            }
        }
    }
}

